def start(args):
	print('algorithm: range start')
	input = args['input'][0]
	array = list(range(input))
	return array
